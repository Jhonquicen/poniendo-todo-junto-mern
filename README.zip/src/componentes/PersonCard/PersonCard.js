import React from "react";

class PersonCard extends React.Component {

    render() {
        const { nombre, apellido, edad, color } = this.props;
        return( 
            <div className="card">
                <h4>{nombre}, {apellido}</h4>
                <p><b>Edad: </b> {edad}</p>
                <p><b>Color de ojos: </b> {color}</p>
            </div>
        )
    }
}
export default PersonCard; //para exportar este componente con el nombre de la clase

