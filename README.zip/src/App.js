import React from "react";
import PersonCard from "./componentes/PersonCard/PersonCard";


class App extends React.Component {

  render() {

    return(
      <div>

        <PersonCard color="gris" nombre="Jorge" apellido="Velez" edad="20"/>
        <PersonCard color="verde" nombre="Maria" apellido="Franco" edad="31"/>
        <PersonCard color="azul" nombre="Johana" apellido="Fernandez" edad="20"/>
        <PersonCard color="miel" nombre="Ferney" apellido="Sossa" edad="31"/>

      </div>
    );
  }
}
export default App;
